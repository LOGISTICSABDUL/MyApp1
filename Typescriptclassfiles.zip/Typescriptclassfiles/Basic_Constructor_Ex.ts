class SampleFour{
    constructor(msg:string){
        console.log(msg);
    }
    
}

var SampleFourObj=new SampleFour("hi everyone good morning");
//SampleFourObj.displaymessage();