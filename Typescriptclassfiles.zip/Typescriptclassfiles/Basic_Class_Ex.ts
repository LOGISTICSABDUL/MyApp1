class SampleOne{

     add(){
        console.log('this is add method');
    }
}

var SampleOneObj=new SampleOne();
SampleOneObj.add();
