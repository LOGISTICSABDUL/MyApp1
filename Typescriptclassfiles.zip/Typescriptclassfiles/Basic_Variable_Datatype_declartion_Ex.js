/* var n:Number =45.6
c */