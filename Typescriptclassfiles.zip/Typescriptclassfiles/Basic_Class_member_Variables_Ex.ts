class SampleTwo{

    name:string;
   setname(){
      this.name="Abdul";
   }
   getname(){
       console.log(this.name);
   }
}
var SampletwoObj=new SampleTwo;
SampletwoObj.setname();
SampletwoObj.getname();

