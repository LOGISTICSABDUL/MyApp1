//var Keyword
/* var x=10;
x=15;
var x=20;
console.log(x); */
//let keyword
/* let r = 25;
r = 30;
let r = 35;
console.log(y); */
