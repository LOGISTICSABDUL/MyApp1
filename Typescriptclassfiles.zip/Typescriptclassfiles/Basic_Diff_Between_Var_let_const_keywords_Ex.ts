//var Keyword

/* var x=10;
x=15;
var x=20;
console.log(x); */

//let keyword
let y=25;
y=30;
let y=35;
console.log(y);
