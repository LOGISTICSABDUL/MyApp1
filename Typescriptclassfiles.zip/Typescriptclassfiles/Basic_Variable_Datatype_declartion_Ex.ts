var n:number =90.0;
var y:number=19;
var x:number=78.9876;
var b:boolean=false;
var isadded:boolean=true;
var s:string="Hello raheem this string";
var sample:undefined=undefined;
let samplenull:null=null;
var price:any=90.8765;
var price2:any="90.8795";
var totalvalue :string| number="300";
var student:string[] =["raheem","abdul"]
var multipledata:[boolean,string]=[true,"raheem"];
console.log("value of m="+n+":value of y="+y+":value of x="+x);


let person:unknown='John';
console.log("unknown="+person);


var unknownType:any=4;
unknownType="Okay I m typing";

console.log("unknownType"+unknownType);


console.log("string="+s);
console.log("Boolean="+b);

console.log(isadded);
console.log(sample);
console.log(samplenull);
console.log(price);
console.log(price2);
console.log(totalvalue);
console.log(student[0]);
console.log(student);
console.log(multipledata);