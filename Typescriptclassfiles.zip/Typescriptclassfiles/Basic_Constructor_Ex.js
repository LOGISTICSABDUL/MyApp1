var SampleFour = /** @class */ (function () {
    function SampleFour(msg) {
        console.log(msg);
    }
    return SampleFour;
}());
var SampleFourObj = new SampleFour("hi everyone good morning");
//SampleFourObj.displaymessage();
