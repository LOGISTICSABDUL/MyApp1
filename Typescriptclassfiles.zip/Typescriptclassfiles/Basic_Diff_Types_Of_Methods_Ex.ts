//Naming Function Without Params
/*function add(){
    console.log('this is naming add method');
}
add();*/

//Naming function with params
/*function add(a:number,b:number){
console.log(a+b);
}
add(6,4);*/

//Anonymous method without params
/*var add= function(){
console.log('this is anonymous add method');
}
add();*/

//Anonymous method with params
/*var add=function(a:number,b:number){
console.log(a+b);
}
add(6,8);*/

//Lamda method or fat arrow method without params

/*var add=()=>{
console.log('this is lamda add method');
}
add();*/

//Lamda method or fat arrow method with params
/*var add=(a:number,b:number)=>{
console.log(a+b);
}
add(4,5);*/

var samplesix=a=> a;

console.log(samplesix(4));

