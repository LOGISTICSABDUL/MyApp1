class SampleFive{
    displaymessage(){
        console.log("Hi everyone good morning");
    }
}

class sampleSix extends SampleFive{
    
    welcomemessage(){
console.log("Hi Everyone welcome to typescript classess");
    }
}

/* var SamplesixObj=new sampleSix;
SamplesixObj.displaymessage();
SamplesixObj.welcomemessage(); */

/* var samplefiveObj=new SampleFive;
samplefiveObj.displaymessage();
samplefiveObj.welcomemessage(); */
